from django.contrib import admin
from bfb_app.models import Artist,Venue,Genre,Promoter,Advert

admin.site.register(Artist)
admin.site.register(Venue)
admin.site.register(Genre)
admin.site.register(Promoter)
admin.site.register(Advert)
