from bfb_app.models import Genre,Artist,Venue,Promoter,Advert

g = Genre(genre='Alternative Music').save()

g = Genre(genre='Blues').save()

g = Genre(genre='Classical Music').save()

g = Genre(genre='Country Music').save()

g = Genre(genre='Dance Music').save()

g = Genre(genre='Easy Listening').save()

g = Genre(genre='Electronic Music').save()

g = Genre(genre='European Music (Folk / Pop)').save()

g = Genre(genre='Hip Hop / Rap').save()

g = Genre(genre='Indie Pop').save()

g = Genre(genre='Inspirational (incl. Gospel)').save()

g = Genre(genre='Asian Pop (J-Pop, K-pop)').save()

g = Genre(genre='Jazz').save()

g = Genre(genre='Latin Music').save()

g = Genre(genre='New Age').save()

g = Genre(genre='Opera').save()

g = Genre(genre='Pop (Popular music)').save()

g = Genre(genre='R&B / Soul').save()

g = Genre(genre='Reggae').save()

g = Genre(genre='Rock').save()

g = Genre(genre='Singer / Songwriter (inc; Folk)').save()

g = Genre(genre='World Music / Beats').save()

    
venue = Venue(name="Oran Mor", address="Byres Rd  Glasgow G12 8QX",website="http://oran-mor.co.uk/")
venue.save()
venue = Venue(name="02 ABC" , address = "300 Sauchiehall St  Glasgow, Lanarkshire G2 3JA",website = "http://www.o2abcglasgow.co.uk/")
venue.save()
venue = Venue(name ="Box",address ="431 Sauchiehall St  Glasgow G2 3LG", website="http://boxglasgow.co.uk/")
venue.save()
venue = Venue(name="Stereo",address="22-28 Renfield Ln  Glasgow G2 6PH", website="http://www.stereocafebar.com/")
venue.save()
venue = Venue(name="Pivo Pivo", address="15 Waterloo St  Glasgow G2 6AY", website="https://plus.google.com/110023145115812766440/about?gl=uk&hl=en")
venue.save
    
    
    
    
    
    
    

